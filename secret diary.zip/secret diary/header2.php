<!doctype html>
<html lang="eng">
<head>
<meta charset="utf-8">
<meta http-eqiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width,initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" type="text/css" href="css\bootstrap.css">
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" type="text/css" href="body2.css">
<link rel="stylesheet" type="text/css" href="jquery-ui\jquery-ui.css">
<title>Secret Diary</title>


</head>
		<body>